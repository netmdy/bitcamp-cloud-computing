USE CASE 모델과 명세서를 두는 폴더
